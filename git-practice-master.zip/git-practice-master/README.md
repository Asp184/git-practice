# Git Practice

This is a repository to practice Git commands and some features of GitHub.


## License

MIT License (c) 15-131 Course Staff
